const mongoose = require('mongoose')

const schema = new mongoose.Schema({
    uid: {
        type: String,
        required: true
    },
    items: {
        type: Object,
        required: true
    },
    credit: {
        type: String,
        required: true
    }
}, {
    collection: "cart"
})

module.exports = mongoose.model('cart', schema)