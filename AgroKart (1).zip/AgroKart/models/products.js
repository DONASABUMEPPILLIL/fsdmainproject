const mongoose = require('mongoose')

const schema = new mongoose.Schema({
    product: {
        type: String,
        required: true
    },
    type: {
        type: String,
        required: true
    },
    quantity: {
        type: String,
        required: true
    },
    unit: {
        type: String,
        required: true
    },
    cover: {
        data: Buffer,
        contentType: String
    },
    seller_id: {
        type: String,
        required: true
    },
    price: {
        type: String,
        required: true
    }
}, {
    collection: "products"
})

module.exports = mongoose.model('products', schema)