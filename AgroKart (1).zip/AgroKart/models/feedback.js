const mongoose = require('mongoose')

const schema = new mongoose.Schema({
    user: {
        type: String,
        required: true
    },
    feedback: {
        type: String,
        required: true
    }
}, {
    collection: "feedback"
})

module.exports = mongoose.model('feedback', schema)