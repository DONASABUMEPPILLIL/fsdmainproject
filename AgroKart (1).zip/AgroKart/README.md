# AgroKart

**Technology Stacks**

ExpressJS|MongoDB|EJS

**User Modules**

Registration|Login|Add Items|View Items|Cart and Checkout|Feedbacks

**Admin Modules**

Login|View and Delete Users|View and Delete Items|Review Feedbacks
