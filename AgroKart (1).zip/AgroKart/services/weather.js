
const request = require('request');

module.exports = {
    get: async (lat, lon, callback) => {
        let url = 'https://api.openweathermap.org/data/2.5/weather?lat=' + lat + '&lon=' + lon + '&appid=' + process.env.appId + '&units=metric'
        request(url, function (error, response, body) {
            let b = JSON.parse(body)
            let d = {
                loc: b.name,
                temp: b.main.temp
            }
            return callback(d)
        })
    }
}