var nodemailer = require('nodemailer');
var otpGenerator = require('otp-generator')

module.exports = {
    send: (mail_id) => {
        otp = otpGenerator.generate(6, { digits: true, specialChars: false, alphabets: false, upperCase: false });
        
        var mail = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: 'storebook375@gmail.com',
              pass: 'bookstore@123'
            }
          });
        
        var mailOptions = {
            from: 'storebook375@gmail.com',
            to: mail_id,
            subject: 'OTP from Bookstore',
            text: 'Please confirm your email by entering the verification code: '+ otp
          };
          
          mail.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
            } else {
              console.log('Email sent: ' + info.response);
            }
          });
          return otp
    }
}