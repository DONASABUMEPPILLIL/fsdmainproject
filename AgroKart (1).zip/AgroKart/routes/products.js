const express = require('express')
const router = express.Router()
const products = require('../models/products')

router.get('/', async(req, res) => {
    try{
        if(req.session.isLoggedIn == 'true'){
            let d = req.query.type
            let p = await products.find({type: d})
            res.render('products', {products: p})
        }
        else{
            res.redirect('/login')
        }
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router