const express = require('express')
const router = express.Router()
const book = require('../models/products')
const cart = require('../models/cart')

router.post('/', async(req, res) => {
    try{
        let c = await cart.findOne({ uid: req.session.user })
        let amount = 0
        for(let i in c.items){
            let t = await book.findById(c.items[i].bid)
            let p = t.price * c.items[i].n
            amount = amount + p
        }
        c.credit = c.credit - amount
        let t = await cart.updateOne({ uid: req.session.user }, { items: [], credit: c.credit })
        res.send("Ok")
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router