const express = require('express')
const router = express.Router()
const weather = require('../services/weather')

router.get('/', async(req, res) => {
    try{
        let lat = req.query.lat
        let lon = req.query.lon
        weather.get(lat,lon, (result)=> {
            let el = result.loc+'<br>'+result.temp +'°C'
            res.send(el)
        })
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router