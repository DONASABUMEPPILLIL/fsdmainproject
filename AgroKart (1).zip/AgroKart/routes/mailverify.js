const express = require('express')
const router = express.Router()
const verify = require('../models/verify')
const user = require('../models/user')
const cart = require('../models/cart')

router.get('/', async (req, res) => {
    try {
        res.render('verify')
    }
    catch (e) {
        res.send('Error:' + e)
    }
})
router.post('/', async (req, res) => {
    try {
        let otp = req.body.otp
        let em = req.session.vemail
        delete req.session.vemail
        let v = await verify.findOne({ email: em})
        if(v != null){
            if (v.otp == otp) {
                let u = new user({
                    username: v.username,
                    password: v.password,
                    email: v.email,
                    type: v.type
                })
                const t = await u.save()
                let c = new cart({
                    uid: t._id,
                    items: [],
                    credit: "1000"
                })
                await c.save()
                res.render('login', { msg: "User created successfuly. You may now login." })
            }
            else{
                res.render('verify', {msg: "Registration failed!! Verification code doesn't match"})
            }
        }
        else{
            res.render('verify', {msg: "You ran out of time. Verification code was destroyed."})
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

module.exports = router