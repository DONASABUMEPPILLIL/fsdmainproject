const express = require('express')
const router = express.Router()

router.get('/', async(req, res) => {
    try{
        if(req.session.isLoggedIn == 'true'){
            res.render('dashboard')
        }
        else{
            res.redirect('/login')
        }
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router