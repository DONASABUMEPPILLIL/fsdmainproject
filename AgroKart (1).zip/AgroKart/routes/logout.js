const express = require('express')
const router = express.Router()

router.get('/', async(req, res) => {
    try{
        req.session.user=null;
        req.session.type = "";
        req.session.isLoggedIn = false;
        res.redirect('/')
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router