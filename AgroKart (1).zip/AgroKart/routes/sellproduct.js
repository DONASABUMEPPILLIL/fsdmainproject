const express = require('express')
const router = express.Router()
const products = require('../models/products')
var multer = require('multer')
const fs = require('fs')
var path = require('path')

var upload = multer({ dest: '../uploads/' });

router.get('/', async (req, res) => {
    try {

        if (req.session.isLoggedIn == 'true') {
            res.render('sellproduct')
        }
        else{
            res.redirect('/login')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/', upload.single('cover'), async (req, res) => {
    try {
        console.log(req.body)
        let p = new products({
            product: req.body.product,
            type: req.body.type,
            quantity: req.body.quantity,
            unit: req.body.unit,
            seller_id: req.session.user,
            cover: {
                data: fs.readFileSync('../uploads/' + req.file.filename),
                contentType: 'image/png'
            },
            price: req.body.price
        })
        const t = await p.save()
        res.redirect('/dashboard')
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

module.exports = router