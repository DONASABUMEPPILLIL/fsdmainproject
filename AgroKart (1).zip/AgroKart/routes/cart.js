const express = require('express')
const router = express.Router()
const product = require('../models/products')
const cart = require('../models/cart')

router.get('/', async (req, res) => {
    try {
        if (req.session.isLoggedIn == 'true') {
            let c = await cart.findOne({ uid: req.session.user })
            let p = []
            for (let i in c.items) {
                let t = await product.findById(c.items[i].bid)
                t.n = c.items[i].n
                p.push(t)
            }
            res.render('cart', { products: p, credit: c.credit, cartId: c._id })
        }
        else {
            res.redirect('/login')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/add', async (req, res) => {
    try {
        let flag = 0
        let q = req.query.quantity
        let c = await cart.findOne({ uid: req.session.user })
        let b = await product.findById(req.body.itemId)
        if(parseInt(b.quantity) < parseInt(q)){
            res.send("Quantity exceeds the available stock on hand.")    
        }
        else{
            c.items.forEach(el => {
                if (el.bid.equals(b._id)) {
                    el.n = parseInt(el.n) + parseInt(q)
                    flag = 1
                }
            })
            if (flag == 0) {
                c.items.push({
                    bid: b._id,
                    n: q
                })
            }
            let nq = b.quantity - q
            await product.updateOne({_id: req.body.itemId}, {quantity: nq})
            await cart.updateOne({ uid: req.session.user }, { items: c.items })
            res.send("Item added to cart")
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/remove', async (req, res) => {
    try {
        let c = await cart.findOne({ uid: req.session.user })
        for(let i in c.items){
            if (c.items[i].bid.equals(req.body.productId)) {
                c.items.splice(i, 1)
            }
        }
        let t = await cart.updateOne({ uid: req.session.user }, { items: c.items })
        res.sendStatus(200)
    }
    catch (e) {
        res.send("Error: ", e)
    }
})
module.exports = router