const express = require('express')
const router = express.Router()
const user = require('../models/user')

router.get('/', async (req, res) => {
    try {
        if((req.session.isLoggedIn == 'true')&&(req.session.type == 'admin')){
            let u = await user.find({type: "user"})
            res.render('users', {users: u})
        }
        else {
            res.redirect('/login')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/remove', async (req, res) => {
    try {
        let t = await user.deleteOne({ _id: req.body.userId })
        res.sendStatus(200)
    }
    catch (e) {
        res.send("Error: ", e)
    }
})

module.exports = router