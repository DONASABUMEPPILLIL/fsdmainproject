function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
      console.log("Geolocation is not supported by this browser.");
    }
  }
  
  function showPosition(position) {
    console.log('Inside')
    $.get('/location', { lat: position.coords.latitude, lon: position.coords.longitude},function(result){
        let w = document.createElement('div')
        w.setAttribute('class','weather')
        w.innerHTML = result
        document.body.appendChild(w)
    })
  }